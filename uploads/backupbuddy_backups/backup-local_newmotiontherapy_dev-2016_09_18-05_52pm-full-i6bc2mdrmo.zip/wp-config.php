<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'local-newmotionphyisicaltherapy-dev');

/** MySQL database username */
define('DB_USER', 'wp');

/** MySQL database password */
define('DB_PASSWORD', 'wp');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define("BACKUPBUDDY_API_ENABLE",true);
define("WP_CACHE",false);
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '5cXA`G0@VjF~h5:O_HmdM+9R5ga-rO2}Un)M>!030Rj~_9!qB+G[RitED0nVLGJI');
define('SECURE_AUTH_KEY',  '6XOFY]Ww_{t.lSs{wp+JDF`[gXK*_VjL.S9T#YPTJ$W]*} CvbXt4gQz@ZKBiY>^');
define('LOGGED_IN_KEY',    'KeJ>}`zo4Cd1l .w7$K7/-,?d^h`]ES1me$UGM`U]m_d&AZL.fp`A&lm1l+wRL3e');
define('NONCE_KEY',        '!cZKq>e% 2K}dKi;Ivz}S|TA35dQ]0I*.q|db^Sr7F0<X-oqRg~YFPw,w!h,ezfP');
define('AUTH_SALT',        'g2wTAazd++%.U9=+6!JgLp:MW-pp|1XY`Z-sq_k:XPf]-dZ<]_7X4fgDvG^}-V-W');
define('SECURE_AUTH_SALT', ',aG5DT !|BJw=v.+LdU grG$9HP+Dr1 !U}-~?9{4fFYmnI/sx:^8cNO9a /h_+]');
define('LOGGED_IN_SALT',   'WOzdbWxI5I%YK-41kE&H9l,AnXApf3!nTV[ {5oR+{p*GF:B|?oPw`H4-&HyXN4-');
define('NONCE_SALT',       'Gh/K8c??[33R[i>L6l]w),UV.lD0Tf=[3(ETKi:KltWaj)knvwki/Yj.Z1l7}2?;');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


define( 'WP_DEBUG', true );
define( 'WP_DEBUG_DISPLAY', false );
define( 'WP_DEBUG_LOG', true );
define( 'SCRIPT_DEBUG', true );
define( 'JETPACK_DEV_DEBUG', true );
if ( isset( $_SERVER['HTTP_HOST'] ) && preg_match('/^(local-newmotionphyisicaltherapy-dev.)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(.xip.io)\z/', $_SERVER['HTTP_HOST'] ) ) {
define( 'WP_HOME', 'http://' . $_SERVER['HTTP_HOST'] );
define( 'WP_SITEURL', 'http://' . $_SERVER['HTTP_HOST'] );
}


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');;;
